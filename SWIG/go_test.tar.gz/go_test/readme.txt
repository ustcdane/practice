go 通过swig调用c++
go 文件为runme.go
运行:
sh build.sh

